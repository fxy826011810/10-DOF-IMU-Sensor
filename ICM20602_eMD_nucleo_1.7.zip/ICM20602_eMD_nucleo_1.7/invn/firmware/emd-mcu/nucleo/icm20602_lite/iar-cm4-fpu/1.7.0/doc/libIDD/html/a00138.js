var a00138 =
[
    [ "inv_icm20690_compass_id", "a00138.html#gadabbcf333fcab078ef0d0070f5ea800f", [
      [ "INV_ICM20690_COMPASS_ID_NONE", "a00138.html#ggadabbcf333fcab078ef0d0070f5ea800fa44522076cd8c39fa042e09689d7f83a4", null ],
      [ "INV_ICM20690_COMPASS_ID_AK09911", "a00138.html#ggadabbcf333fcab078ef0d0070f5ea800fa95af031749931e3e8bc00f961d305616", null ],
      [ "INV_ICM20690_COMPASS_ID_AK09912", "a00138.html#ggadabbcf333fcab078ef0d0070f5ea800fac1c8b418e3aaea25288c129d688d3536", null ]
    ] ],
    [ "inv_icm20690_check_akm_self_test", "a00138.html#gaae4656bf78f112711fe059bfc5e6119c", null ],
    [ "inv_icm20690_compass_getstate", "a00138.html#gaec0e8a979887a8fd35d57f7997016115", null ],
    [ "inv_icm20690_get_compass_bytes", "a00138.html#ga9a11343274ea03c0394a4b8cc19593b8", null ],
    [ "inv_icm20690_get_compass_data", "a00138.html#gae0154976f65ac69cab5c7414a4530870", null ],
    [ "inv_icm20690_is_compass_registered", "a00138.html#ga6eb3f66b3063dc44583efebde0e50c83", null ],
    [ "inv_icm20690_read_akm_scale", "a00138.html#gafdf384330a0bc051fc75d2bfb6c9a1d7", null ],
    [ "inv_icm20690_register_aux_compass", "a00138.html#ga2dbe21c7a6f74a898f15e77b6d81b94f", null ],
    [ "inv_icm20690_resume_akm", "a00138.html#gaef3c5b97ba0c03cc92f808a5efa4cbe7", null ],
    [ "inv_icm20690_setup_compass_akm", "a00138.html#gab4b79e0ffb5566a553dd03723b7b5ece", null ],
    [ "inv_icm20690_suspend_akm", "a00138.html#ga5c63dd41410d5403d87af55ecf5a4f79", null ]
];