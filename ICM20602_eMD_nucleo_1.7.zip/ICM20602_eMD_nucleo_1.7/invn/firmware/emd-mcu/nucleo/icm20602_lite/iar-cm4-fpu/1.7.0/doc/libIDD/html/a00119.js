var a00119 =
[
    [ "inv_host_serif", "a00027.html", [
      [ "close", "a00027.html#a19b12568b42cd3054d01b090b72aa9e8", null ],
      [ "max_read_size", "a00027.html#abbf6792074059b384bba28c43e3323b6", null ],
      [ "max_write_size", "a00027.html#af03843e235f65d488d7d5a5bb89327e2", null ],
      [ "open", "a00027.html#a17c053aa1d0da865795be0fe83ddcc00", null ],
      [ "read_reg", "a00027.html#a5839f8fc39a22b8bd84c1e1356ae6fdc", null ],
      [ "register_interrupt_callback", "a00027.html#a82ad6c685693b4d32fe94611c04e128b", null ],
      [ "serif_type", "a00027.html#a7bd156558b438b41f198333a0bad50d5", null ],
      [ "write_reg", "a00027.html#ade31f6de16a7a30795f184a54c89653d", null ]
    ] ],
    [ "inv_host_serif_t", "a00119.html#gabee8d8f42fc9483d3cfe26034e5897a1", null ],
    [ "inv_host_serif_error", "a00119.html#ga8c269f067bd83f86dbd4e7dfd6b2b827", null ],
    [ "inv_host_serif_type", "a00119.html#ga43d5854cb21c105f61262aedf9e0891d", null ],
    [ "inv_host_serif_close", "a00119.html#ga21c38ce3f793ffbb7597cd223df007c2", null ],
    [ "inv_host_serif_get_instance", "a00119.html#ga30537d2fa3383cd0cb2617129b00db71", null ],
    [ "inv_host_serif_get_max_read_transaction_size", "a00119.html#gaba12f24086e4c3f4a573f52b7eb88b3b", null ],
    [ "inv_host_serif_get_max_write_transaction_size", "a00119.html#ga40f878b0def491b392ca6612cbb01cdf", null ],
    [ "inv_host_serif_get_type", "a00119.html#ga0a6cbe9bd790bb311f8720d37c2b5331", null ],
    [ "inv_host_serif_is_i2c", "a00119.html#ga4303068a5b50ef9a3485b62a0bfdbdfa", null ],
    [ "inv_host_serif_is_spi", "a00119.html#gafc2de0f6e2c97cf7b3008fe6662fabca", null ],
    [ "inv_host_serif_open", "a00119.html#ga40726a09c28a8a5ef7cf6aaf2e93d05d", null ],
    [ "inv_host_serif_read_reg", "a00119.html#gaaea39f3b20bdecbf62b225cca308e71a", null ],
    [ "inv_host_serif_register_interrupt_callback", "a00119.html#ga03a4224e8f06aafe97366cc36976a819", null ],
    [ "inv_host_serif_set_instance", "a00119.html#ga3f62c5f30940ff5cd10e9dc0e8a0ea3b", null ],
    [ "inv_host_serif_write_reg", "a00119.html#ga338bada055f5e106391fe191232c4a90", null ]
];