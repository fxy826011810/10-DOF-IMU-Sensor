var a00118 =
[
    [ "inv_device_icm20690", "a00020.html", null ],
    [ "inv_device_icm20690_config_bias_st", "a00021.html", [
      [ "acc_bias_lp", "a00021.html#ad7289192646405225c75f3ec5eeca604", null ],
      [ "acc_bias_nl", "a00021.html#a4b3e8b59e6cec84c12c7e90ee554793c", null ],
      [ "gyr_bias_lp", "a00021.html#a3d9e82b87a1afeda86e59129f14ba0be", null ],
      [ "gyr_bias_nl", "a00021.html#a5707be748989260ed2a22b720b2583f0", null ]
    ] ],
    [ "inv_device_icm20690_config_bias_st_t", "a00118.html#ga8d47a6880659ed658731988538ae164d", null ],
    [ "inv_device_icm20690_config_wom_threshold_t", "a00118.html#ga101cc2f7ec22ddc84b72a139df13d26a", null ],
    [ "inv_device_icm20690_t", "a00118.html#gac8bf0db6db57f2c6187f75a1d3e696c9", null ],
    [ "inv_device_icm20690_config", "a00118.html#gaf93f02617eac921178abf2f5dcaa9f9d", null ],
    [ "inv_device_icm20690_get_base", "a00118.html#ga9acde9062f5e808c251f0f5342cb58f5", null ],
    [ "inv_device_icm20690_init", "a00118.html#gafd508affbba604c915671a3ee10e4cac", null ],
    [ "inv_device_icm20690_init2", "a00118.html#ga436fd687074e5f4bfe19058508ff683f", null ],
    [ "inv_device_icm20690_init_aux_compass", "a00118.html#gad414fdab9a5cc27bfb47d6e689df29f4", null ],
    [ "inv_device_icm20690_init_serif_ois", "a00118.html#ga390575caa8c840e3dafd63e63a60753a", null ],
    [ "inv_device_icm20690_init_serif_ois2", "a00118.html#gaa0d1ff2d96a263aa3ccdf230a16d77b6", null ]
];