var searchData=
[
  ['mag',['mag',['../a00059.html#a381ae276db68acc7dfb1e5e7ccc609dd',1,'inv_sensor_event']]],
  ['max_5fread_5fsize',['max_read_size',['../a00027.html#abbf6792074059b384bba28c43e3323b6',1,'inv_host_serif']]],
  ['max_5fwrite_5fsize',['max_write_size',['../a00027.html#af03843e235f65d488d7d5a5bb89327e2',1,'inv_host_serif']]],
  ['message',['Message',['../a00122.html',1,'']]]
];
