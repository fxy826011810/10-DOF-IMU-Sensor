var a00022 =
[
    [ "base", "a00114.html#ga2ce4df0deaa18863c1c05b5c48dec47d", null ],
    [ "base_chip_info", "a00114.html#ga3176775b195d7b91a9c6a9ed27eb4198", null ],
    [ "graph_leaves", "a00114.html#ga0a0a3516111b06bbbd985c79a4504202", null ],
    [ "graph_roots", "a00114.html#ga531a030bd755c1a6a285eb6fe853ec40", null ],
    [ "hw_device", "a00114.html#ga5318b3a71b8e81fd3b54076319dc1f0e", null ],
    [ "hw_sensor_available_mask", "a00114.html#ga3a3cc4d2fab135cf9d24c6e726e8cdb9", null ],
    [ "l", "a00114.html#ga31eb486b16de1104bf171838491bb339", null ],
    [ "leaves_list", "a00114.html#ga79230f6f27677cfa389285aa2d5b6ae9", null ],
    [ "private_idd_listener", "a00114.html#ga4c3db042fd9da9d86f8f774240333866", null ],
    [ "s", "a00114.html#ga079310b541fc932c83b8ace8e6c6fd2a", null ]
];