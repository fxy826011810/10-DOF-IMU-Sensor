var a00124 =
[
    [ "inv_icm20602_compass_id", "a00124.html#ga907c958efcc35c632ba35137d8244119", [
      [ "INV_ICM20602_COMPASS_ID_NONE", "a00124.html#gga907c958efcc35c632ba35137d8244119aa4adbdc3a8067dcfa8519c9e27a6b3ed", null ],
      [ "INV_ICM20602_COMPASS_ID_AK09911", "a00124.html#gga907c958efcc35c632ba35137d8244119a225014af6bfc598e0843789c5e576733", null ],
      [ "INV_ICM20602_COMPASS_ID_AK09912", "a00124.html#gga907c958efcc35c632ba35137d8244119a7e3a2a160e63dfa2d859849a69d6a4cf", null ]
    ] ],
    [ "inv_icm20602_check_akm_self_test", "a00124.html#gadec6ffcd3f9f5cd17a96223a398f4ab8", null ],
    [ "inv_icm20602_compass_getstate", "a00124.html#ga22a8e5f5fd631468cdb2bf6b70de004e", null ],
    [ "inv_icm20602_get_compass_bytes", "a00124.html#gac1c06b084f41594e79dedb5ff72b5ae9", null ],
    [ "inv_icm20602_get_compass_data", "a00124.html#gaf7cc79465939f11ae5eddb36160fe29f", null ],
    [ "inv_icm20602_is_compass_registered", "a00124.html#gacf83554e2aac2567b93a3ab5c767a3c5", null ],
    [ "inv_icm20602_read_akm_scale", "a00124.html#gaaf4335e25669546c70e112e86f6a6eeb", null ],
    [ "inv_icm20602_register_aux_compass", "a00124.html#gab821f1fa8ba53cb7f583530500ede2a5", null ],
    [ "inv_icm20602_resume_akm", "a00124.html#ga85562bf1a040ce1d8d9aee129f1547e8", null ],
    [ "inv_icm20602_setup_compass_akm", "a00124.html#gabd9fe55a3c4c182e1e2576080404c65b", null ],
    [ "inv_icm20602_suspend_akm", "a00124.html#ga065d4ef140aea5783b1722d418549447", null ]
];