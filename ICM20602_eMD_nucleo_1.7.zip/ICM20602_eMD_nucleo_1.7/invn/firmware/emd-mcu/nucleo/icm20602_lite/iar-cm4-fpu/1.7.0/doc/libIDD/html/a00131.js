var a00131 =
[
    [ "inv_icm20603_compass_id", "a00131.html#ga1203ba09ca0ed45a05a23c8bf1270694", [
      [ "INV_ICM20603_COMPASS_ID_NONE", "a00131.html#gga1203ba09ca0ed45a05a23c8bf1270694a74fc391b8f380e0af5d3d67c58536c0b", null ],
      [ "INV_ICM20603_COMPASS_ID_AK09911", "a00131.html#gga1203ba09ca0ed45a05a23c8bf1270694a45d35ed247d17e5abf7b25899afd8eb7", null ],
      [ "INV_ICM20603_COMPASS_ID_AK09912", "a00131.html#gga1203ba09ca0ed45a05a23c8bf1270694a7b17314a74c3c8465afd3856449eaad5", null ]
    ] ],
    [ "inv_icm20603_check_akm_self_test", "a00131.html#ga8329718b09dec1b78ae8be99aba292e3", null ],
    [ "inv_icm20603_compass_getstate", "a00131.html#gada628f048e0d7252ea4dc0f7760a6919", null ],
    [ "inv_icm20603_get_compass_bytes", "a00131.html#gab2526b457c08f159a58c00858a55e33d", null ],
    [ "inv_icm20603_get_compass_data", "a00131.html#ga2896b5ec3a6c8eab5b552dffd3419069", null ],
    [ "inv_icm20603_is_compass_registered", "a00131.html#gaa2063a411051e4da605d00f7c82c0123", null ],
    [ "inv_icm20603_read_akm_scale", "a00131.html#ga14134273f6438e56a203390be93713d2", null ],
    [ "inv_icm20603_register_aux_compass", "a00131.html#gadbb2082e69793638acd76bd6b0c05692", null ],
    [ "inv_icm20603_resume_akm", "a00131.html#ga2b364f2bbbf6b93958a7046e0a2bb912", null ],
    [ "inv_icm20603_setup_compass_akm", "a00131.html#ga4c879f68b35963af9709d81294e1b641", null ],
    [ "inv_icm20603_suspend_akm", "a00131.html#ga20041e573d203e5f79e7c3657d4eb835", null ]
];